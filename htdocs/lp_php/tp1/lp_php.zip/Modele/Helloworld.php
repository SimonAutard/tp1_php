<?php

final class Helloworld
{
    private $_S_message = "Hello World";

    public function donneMessage()
    {
        return $this->_S_message ;
    }

}