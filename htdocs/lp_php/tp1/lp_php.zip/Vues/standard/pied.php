<footer class="footer">
    <div class="content has-text-centered">
        <p> Site réalisé dans le cadre du <b> TP n°1 </b> du module <a href="#"> "Développement de sites web dynamiques et référencements"</a> de la LP DEV WEB</p>
    </div>
</footer>