<div class="hero is-primary">
    <div class="hero-body">
        <div class="container">
            <h1 class="title">
                randomstu.dent
            </h1>
            <h2 class="subtitle">
                Créez vos groupes d'étudiants à distance sans souci
            </h2>
        </div>
    </div>
</div>