<?php

echo "<p>" . $A_vue['helloworld']  . "</p>";